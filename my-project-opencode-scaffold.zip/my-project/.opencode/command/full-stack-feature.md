---
description: Implement a feature that spans database, backend, and frontend
agent: orchestrator
---

Feature request: $ARGUMENTS

Follow this sequence:

1. Read `shared-context/feature-status.md` to check whether related work
   already exists.
2. If schema changes are needed, delegate to `@oracle-db-agent` first.
   Wait for it to confirm `shared-context/data-contracts.md` is updated.
3. Delegate the API work to `@spring-boot-agent`, pointing it at the
   updated `data-contracts.md`. Wait for it to confirm
   `shared-context/api-contracts.md` is updated.
4. Delegate the UI work to `@angular-agent`, pointing it at the updated
   `api-contracts.md`.
5. Once all three report done, update `shared-context/feature-status.md`
   with the feature name, date, and status (done end-to-end / partial).
6. Summarize what changed in each stack for the user in 3-5 bullet points
   — do not paste each subagent's full output back verbatim.

If the feature only requires one stack, skip straight to that subagent
instead of running the full sequence.
