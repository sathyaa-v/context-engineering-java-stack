---
description: Run the Spring Boot test suite and summarize failures
agent: spring-boot-agent
subtask: true
---

Run the backend test suite: `[mvn test / ./mvnw test / gradle test]`.

- If everything passes, report a one-line summary.
- If anything fails, show the failing test names and the relevant
  assertion/stack trace excerpt, then propose a fix. Do not apply the fix
  without confirmation unless the user has pre-approved auto-fixes for
  this session.
- Do not touch `frontend/` or `database/` regardless of what the failures
  suggest — report cross-stack suspicions to the user instead.
