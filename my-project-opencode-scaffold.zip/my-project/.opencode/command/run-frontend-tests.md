---
description: Run the Angular test suite and summarize failures
agent: angular-agent
subtask: true
---

Run the frontend test suite: `[ng test / npm test]`.

- If everything passes, report a one-line summary.
- If anything fails, show the failing spec names and the relevant
  assertion excerpt, then propose a fix. Do not apply the fix without
  confirmation unless the user has pre-approved auto-fixes for this
  session.
- Do not touch `backend/` or `database/` regardless of what the failures
  suggest — report cross-stack suspicions to the user instead.
