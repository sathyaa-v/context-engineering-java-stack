---
description: Apply pending Oracle migrations in a controlled way
agent: oracle-db-agent
subtask: true
---

Apply pending database migrations using [Flyway/Liquibase]:

1. First run the tool's **dry-run / info / status** command (not the apply
   command) and show the user exactly which migrations are pending.
2. Wait for explicit confirmation before running the actual apply command.
3. After applying, confirm success and update
   `database/.agent-context/state.md` and `database/.agent-context/schema-notes.md`.
4. Never run this against anything other than the environment the user
   has explicitly named for this session.
