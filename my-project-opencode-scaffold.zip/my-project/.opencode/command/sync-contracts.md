---
description: Re-verify shared-context contracts match actual code across all three stacks
agent: orchestrator
---

Audit `shared-context/api-contracts.md` and `shared-context/data-contracts.md`
against the real codebase:

1. `@oracle-db-agent`: list actual tables/columns relevant to recent changes
   (check `database/.agent-context/session-log.md` for what changed
   recently) and confirm they match `shared-context/data-contracts.md`.
2. `@spring-boot-agent`: list actual REST endpoints, request/response DTOs,
   and confirm they match `shared-context/data-contracts.md` (entity
   mapping) and `shared-context/api-contracts.md` (endpoint shapes).
3. `@angular-agent`: confirm the frontend's typed service interfaces match
   `shared-context/api-contracts.md`.
4. Report any drift found, with file:line references where possible.
5. Ask the user whether to fix the contract docs or the code before making
   any changes — do not silently pick one.
