# [PROJECT_NAME] — Root Project Rules

> This file is loaded into **every** agent session, regardless of which
> agent is active. Keep it short and stack-agnostic. Stack-specific rules
> belong in `backend/AGENTS.md`, `frontend/AGENTS.md`, `database/AGENTS.md`.

## What this project is

[ONE-PARAGRAPH DESCRIPTION OF THE PRODUCT/DOMAIN]

Full-stack application:
- **Frontend** — Angular 19, in `frontend/`
- **Backend** — Spring Boot ([Java/Kotlin version]), in `backend/`
- **Database** — Oracle ([version, e.g. 19c]), in `database/`

## Agents available

| Agent | Type | Use for |
|---|---|---|
| `orchestrator` | primary (default) | Any feature/change that spans more than one stack |
| `spring-boot-agent` | subagent | Backend-only work — call via orchestrator or `@spring-boot-agent` |
| `angular-agent` | subagent | Frontend-only work — call via orchestrator or `@angular-agent` |
| `oracle-db-agent` | subagent | Schema/query-only work — call via orchestrator or `@oracle-db-agent` |

Slash commands: `/full-stack-feature`, `/sync-contracts`, `/run-backend-tests`,
`/run-frontend-tests`, `/run-migration`. See `.opencode/command/`.

## Context rules (non-negotiable)

1. Each stack's `.agent-context/state.md` is a **snapshot** — it gets fully
   overwritten at the end of a session, never appended to.
2. Each stack's `.agent-context/plan.md` uses checkboxes. When a plan is
   fully complete, archive it to `session-log.md` and start a new one.
3. Never load another stack's `.agent-context/` files unless the task
   explicitly requires cross-stack context — use `shared-context/` for that.
4. Never commit secrets, API keys, or DB credentials to any file in this
   repo, including `.agent-context/` notes.
5. When a genuine architectural decision is made, record it in that stack's
   `decisions.md` with a one-line rationale — don't skip this even under
   time pressure; it's what prevents future sessions from re-litigating it.

## Source of truth for cross-stack contracts

- REST API shape: `shared-context/api-contracts.md`
- Entity ↔ table mapping: `shared-context/data-contracts.md`
- High-level architecture: `shared-context/system-architecture.md`
- What's done end-to-end: `shared-context/feature-status.md`

If code and a contract file disagree, treat it as a bug — fix the code or
raise it, don't silently follow the code.

## Global conventions

- Branch naming: `[e.g. feature/<ticket>-short-desc]`
- Commit style: `[e.g. Conventional Commits — feat:, fix:, chore:, docs:]`
- PR checklist: `[e.g. tests pass, contracts updated, state.md updated]`
- CI: `[tool/URL]`
