# [PROJECT_NAME] — Full-Stack OpenCode Agent Scaffold

Stack: **Angular 19** (frontend) · **Spring Boot** (backend) · **Oracle** (database)

This repo is wired for [OpenCode](https://opencode.ai) with a
context-engineered multi-agent setup: one orchestrator for cross-stack
work, and three specialist subagents that each stay scoped to their own
subfolder.

## Quick start

1. Search this repo for `[BRACKETED PLACEHOLDERS]` and fill them in with
   your real project details (versions, package names, DB schema owner,
   naming conventions, run commands, etc.). Start with:
   - `AGENTS.md` (root)
   - `backend/AGENTS.md`, `frontend/AGENTS.md`, `database/AGENTS.md`
   - each `.agent-context/memory.md`
   - `shared-context/system-architecture.md`
2. Copy `backend/`, `frontend/`, `database/` content into (or initialize)
   your actual Spring Boot project, Angular 19 project, and Oracle SQL
   scripts — this scaffold ships the `.agent-context/` and `AGENTS.md`
   layer, not a working app.
3. `cd` into the parent folder and run `opencode`.
4. Default agent is `orchestrator`. Use `/full-stack-feature <description>`
   for work spanning all three stacks, or `@spring-boot-agent`,
   `@angular-agent`, `@oracle-db-agent` to work on one stack directly.
5. At the end of every session, whichever agent you used should have
   rewritten its own `state.md` and ticked boxes in its own `plan.md`.
   Review `.agent-context/` diffs like you'd review code.

## How context is scoped

| File | Loaded when | Rewritten how often |
|---|---|---|
| Root `AGENTS.md` + `opencode.json` `instructions` | Every session, every agent | Rarely — keep it tiny, stack-agnostic |
| `shared-context/*.md` | Only when an agent explicitly references it | When contracts/architecture change |
| `<stack>/AGENTS.md` | Only when that stack's subagent runs | Rarely |
| `<stack>/.agent-context/state.md` | Only when that stack's subagent runs | **Every session** (fully overwritten) |
| `<stack>/.agent-context/memory.md` | Only when that stack's subagent runs | Occasionally |
| `<stack>/.agent-context/plan.md` | Only when that stack's subagent runs | Checkboxes each session; replaced when scope changes |
| `<stack>/.agent-context/decisions.md` | Only on explicit `@mention` | On real architectural decisions |
| `<stack>/.agent-context/session-log.md` | Only on explicit `@mention` | Appended, never auto-loaded |

This is deliberate: opening OpenCode from the parent folder should not
pull backend context into a frontend task or vice versa. Each subagent's
own `.opencode/agent/*.md` file is responsible for loading its own slice
at the start of its own turn — the root config stays minimal.

## Folder map

```
my-project/
├── opencode.json              global config — minimal instructions + agent registry
├── AGENTS.md                  root rules, always loaded, stack-agnostic
├── README.md                  this file
│
├── .opencode/
│   ├── agent/
│   │   ├── orchestrator.md          primary — cross-stack coordinator
│   │   ├── spring-boot-agent.md     subagent — backend/ only
│   │   ├── angular-agent.md         subagent — frontend/ only
│   │   └── oracle-db-agent.md       subagent — database/ only
│   └── command/
│       ├── full-stack-feature.md
│       ├── sync-contracts.md
│       ├── run-backend-tests.md
│       ├── run-frontend-tests.md
│       └── run-migration.md
│
├── backend/                   Spring Boot
│   ├── AGENTS.md
│   └── .agent-context/
│       ├── state.md   memory.md   plan.md   decisions.md   session-log.md
│
├── frontend/                  Angular 19
│   ├── AGENTS.md
│   └── .agent-context/
│       ├── state.md   memory.md   plan.md   decisions.md   session-log.md
│
├── database/                  Oracle
│   ├── AGENTS.md
│   └── .agent-context/
│       ├── state.md   memory.md   plan.md   schema-notes.md   decisions.md   session-log.md
│
└── shared-context/
    ├── api-contracts.md       Spring Boot ↔ Angular
    ├── data-contracts.md      Spring Boot ↔ Oracle
    ├── system-architecture.md loaded globally, keep short
    └── feature-status.md      cross-stack progress view, owned by orchestrator
```

## Maintenance rules

- `state.md` is a snapshot, not a log — overwrite it, don't append.
- `plan.md` uses checkboxes. When every box is checked, archive the
  content into `session-log.md` and start a fresh `plan.md`.
- `decisions.md` only gets a new entry for decisions that would confuse a
  future session if left undocumented.
- Never commit secrets, credentials, or connection strings anywhere in
  this repo, including inside `.agent-context/` notes — reference
  environment variable names only.
- Keep `shared-context/api-contracts.md` and `shared-context/data-contracts.md`
  in sync with real code every session that touches them — treat drift as
  a bug (`/sync-contracts` command exists for this).
