# Backend — Decisions Log

> ADR-style, append-only. One entry per real architectural decision — not
> every small choice. Reference-only: not auto-loaded into every session,
> pull in with `@backend/.agent-context/decisions.md` when relevant.

Format:
```
## [YYYY-MM-DD] Short title
**Decision:** what was decided
**Why:** the reasoning
**Alternatives considered:** what else was on the table, and why rejected
```

---

## [YYYY-MM-DD] Example — DTO mapping strategy
**Decision:** Use MapStruct for entity <-> DTO mapping.
**Why:** Compile-time generated mappers, no reflection overhead, easy to
unit test the generated code directly.
**Alternatives considered:** Manual mapper classes (more boilerplate,
error-prone on field renames); ModelMapper (runtime reflection, harder to
debug mapping bugs).

<!-- Add new entries above this line, most recent first is fine too —
     pick one order and stay consistent. -->
