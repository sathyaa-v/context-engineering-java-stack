# Backend — Memory

> Durable facts, conventions, and gotchas that should survive across every
> session. This is NOT a log — keep it curated and short. Delete entries
> that stop being true.

## Conventions

- Package root: `com.[company].[project]`
- DTO naming: `<Entity>Request` / `<Entity>Response` (e.g. `UserRequest`,
  `UserResponse`), not `<Entity>DTO`.
- Controllers return `ResponseEntity<T>` explicitly, not bare objects.
- Pagination: `[Spring Data Pageable via ?page=&size=&sort= / custom cursor
  — specify]`.
- Error response shape: see `shared-context/api-contracts.md` — do not
  invent a new error format per endpoint.
- Timestamps: stored and returned in UTC ISO-8601; entity fields use
  `Instant`, not `LocalDateTime`, unless there's a documented reason.
- IDs: `[UUID / Oracle sequence-backed BIGINT — specify]`.

## Known gotchas

- [Example: "Oracle treats empty string as NULL — never rely on
  `column = ''` checks; use `IS NULL`."]
- [Example: "ojdbc driver batching requires
  `rewriteBatchedStatements=true`-equivalent config for bulk inserts to be
  fast — see application.yml datasource props."]

## Testing

- Unit tests: `[JUnit 5 + Mockito]`
- Integration tests: `[Testcontainers with Oracle XE image / an Oracle
  test schema — specify]`
- Run: `[mvn test / ./mvnw test]`

## Dependencies worth knowing about

- [List any non-obvious library choices and why, e.g. "MapStruct for
  entity<->DTO mapping instead of manual mappers — generated mappers live
  in target/generated-sources."]
