# Backend — Active Plan

> Checkbox tasks for the CURRENT feature only. When every box is checked,
> move this content into `session-log.md` and clear this file for the
> next feature — don't let it grow into a permanent backlog.

## Feature: [none active — scaffold state]

- [ ] Define initial project structure (`config/`, `controller/`,
      `service/`, `repository/`, `entity/`, `dto/`, `mapper/`, `exception/`)
- [ ] Configure Oracle datasource + connection pool
- [ ] Wire up migration tool ([Flyway/Liquibase]) to run against
      `database/sql/migrations/`
- [ ] Add global exception handler (`@ControllerAdvice`) with the error
      envelope defined in `shared-context/api-contracts.md`
- [ ] Add health check endpoint
- [ ] Add first real domain endpoint: [TBD]
