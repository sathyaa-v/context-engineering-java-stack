# Backend — Session Log

> Append-only, dated, one line per session (or a short block for
> completed plans being archived). Never auto-loaded — reference-only,
> for audits/debugging or when a session explicitly needs history.

Format: `- [YYYY-MM-DD HH:MM] <one-line summary of what changed>`

---

- [YYYY-MM-DD HH:MM] Scaffold created. No feature work yet.
