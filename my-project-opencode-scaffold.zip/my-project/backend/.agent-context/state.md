# Backend — Current State

> This file is a SNAPSHOT. Overwrite it completely at the end of every
> session. Do not append — stale entries make agents trust bad data.

**Last updated:** [YYYY-MM-DD] by [agent/session identifier]

## Status: `not started`

## In progress

- (nothing yet — initial scaffold)

## Blocked

- (none)

## Done recently

- (none yet)

## Next step

- Fill in `backend/AGENTS.md` placeholders (Java/Kotlin version, build tool,
  auth mechanism, package root) before starting real feature work.

## Environment notes

- Local run command: `[e.g. ./mvnw spring-boot:run]`
- Local port: `[e.g. 8080]`
- Required env vars for local dev: `[list names only, no values]`
