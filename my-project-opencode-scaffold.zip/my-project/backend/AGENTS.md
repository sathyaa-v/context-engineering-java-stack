# backend/ — Spring Boot Rules

> Loaded only when `spring-boot-agent` (or a session working directly in
> this folder) is active.

## Stack

- Language: [Java 21 / Kotlin — specify]
- Framework: Spring Boot [version]
- Build: [Maven `pom.xml` / Gradle `build.gradle.kts`]
- Persistence: Spring Data JPA, Oracle via [driver, e.g. ojdbc11]
- Migrations: owned by `database/`, applied via [Flyway/Liquibase] before
  the app boots — the backend never creates/alters tables itself
- Auth: [JWT / OAuth2 / session — specify]
- API docs: [springdoc-openapi / Swagger UI at /swagger-ui.html]

## Package structure

```
com.[company].[project]
├── config/          Spring configuration, security, CORS
├── controller/       REST controllers, DTO in/out only
├── service/          business logic
├── repository/       Spring Data repositories
├── entity/            JPA entities — never returned directly from controllers
├── dto/               request/response DTOs
├── mapper/            entity <-> DTO mapping (MapStruct or manual)
├── exception/         custom exceptions + @ControllerAdvice
└── [module-specific packages as the app grows]
```

## Non-negotiable rules

1. Controllers depend on services; services depend on repositories.
   Controllers never inject a repository directly.
2. Entities are never serialized directly in an API response — always map
   to a DTO.
3. All request bodies are validated with `jakarta.validation` annotations;
   validation errors return a consistent error shape (see
   `shared-context/api-contracts.md` for the error envelope).
4. Every endpoint added/changed updates `shared-context/api-contracts.md`
   in the same session.
5. Every entity added/changed updates `shared-context/data-contracts.md`
   in the same session.
6. No secrets or connection strings in code or config committed to git —
   use `[application.yml + environment variables / Spring Cloud Config /
   Vault — specify]`.
7. New endpoints require: a controller test (MockMvc/WebTestClient) and,
   where logic is non-trivial, a service-layer unit test.

## Context files in this folder

- `.agent-context/state.md` — read first, overwrite last, every session
- `.agent-context/memory.md` — durable conventions/gotchas, update when
  something new is learned
- `.agent-context/plan.md` — active checklist for the current feature
- `.agent-context/decisions.md` — ADR-style log, append-only
- `.agent-context/session-log.md` — dated one-liners, append-only,
  reference-only (not auto-loaded)
