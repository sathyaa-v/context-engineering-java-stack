# Database — Decisions Log

> ADR-style, append-only. Reference-only, not auto-loaded.

Format:
```
## [YYYY-MM-DD] Short title
**Decision:** what was decided
**Why:** the reasoning
**Alternatives considered:** what else was on the table, and why rejected
```

---

## [YYYY-MM-DD] Example — Surrogate key strategy
**Decision:** Use `IDENTITY` columns (Oracle 12c+) for all new tables'
surrogate primary keys.
**Why:** Simpler DDL than sequence+trigger, native `INSERT ... RETURNING`
support, one less object to manage per table.
**Alternatives considered:** Sequence + BEFORE INSERT trigger (rejected —
legacy pattern, more moving parts, no benefit on 12c+); UUID primary keys
(rejected — larger index size, no natural ordering, not needed at this
scale).

<!-- Add new entries above this line. -->
