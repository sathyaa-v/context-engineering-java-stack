# Database — Memory

> Durable facts, conventions, and gotchas. Not a log — keep it curated.

## Conventions

- Tables: `UPPER_SNAKE_CASE`, singular (e.g. `USER_PROFILE`, not
  `USER_PROFILES`) — [confirm this matches actual project convention].
- Surrogate keys: `[Oracle sequence + trigger / IDENTITY column
  (12c+) — specify]`.
- Audit columns on every table: `CREATED_AT`, `CREATED_BY`,
  `UPDATED_AT`, `UPDATED_BY` (`TIMESTAMP WITH TIME ZONE`).
- Soft delete: `[column name, e.g. IS_DELETED / DELETED_AT — specify if
  used, and which tables]`.
- Money/currency columns: `NUMBER(19,4)`, never `FLOAT`/`BINARY_DOUBLE`.
- Booleans: Oracle has no native BOOLEAN in tables pre-23ai — use
  `[NUMBER(1) CHECK (col IN (0,1)) / VARCHAR2(1) CHECK (col IN ('Y','N'))
  — specify project convention]`.

## Known gotchas

- Oracle treats an empty string (`''`) as `NULL` — never rely on
  `column = ''` in WHERE clauses; use `IS NULL` / `IS NOT NULL`.
- `VARCHAR2` max length depends on `MAX_STRING_SIZE` setting
  (4000 STANDARD vs 32767 EXTENDED) — confirm which mode this DB runs in
  before assuming long-text columns will fit.
- Case sensitivity: identifiers are case-insensitive unless
  double-quoted at creation time — avoid quoted mixed-case identifiers
  entirely to prevent quoting mismatches later.
- Sequence + trigger pattern (pre-12c style) vs `IDENTITY` columns
  (12c+) behave differently on `INSERT ... RETURNING` — confirm which
  pattern this project uses before writing DML examples.

## Testing

- Migration test approach: `[apply migrations against a disposable
  Oracle XE/Testcontainers instance in CI — specify]`
- Run: `[command]`

## Reference objects worth knowing about

- [Any views, materialized views, or PL/SQL packages that are load-
  bearing for the app, with a one-line purpose note]
