# Database — Active Plan

> Checkbox tasks for the CURRENT feature only. When complete, archive to
> `session-log.md` and clear this file.

## Feature: [none active — scaffold state]

- [ ] Confirm Oracle version and `MAX_STRING_SIZE` setting
- [ ] Set up migration tool ([Flyway/Liquibase]) config pointing at
      `database/sql/migrations/`
- [ ] Write baseline migration (`V1__baseline_schema.sql` or equivalent)
- [ ] Define audit column standard and apply to baseline tables
- [ ] Build first real feature schema: [TBD]
