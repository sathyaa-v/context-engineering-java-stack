# Database — Schema Notes

> Living reference of tables, indexes, and PL-SQL objects. Update this in
> the same session any schema migration is written. This is what an
> agent should trust over re-deriving the schema from raw SQL files.

## Tables

| Table | Purpose | Key columns | Notes |
|---|---|---|---|
| _(none yet)_ | | | |

## Indexes

| Index | Table | Columns | Purpose |
|---|---|---|---|
| _(none yet)_ | | | |

## Constraints of note

| Constraint | Table | Rule | Why |
|---|---|---|---|
| _(none yet)_ | | | |

## PL/SQL objects

| Object | Type | Purpose | Called from |
|---|---|---|---|
| _(none yet)_ | | | |

## Views / Materialized Views

| Name | Purpose | Refresh strategy (if MV) |
|---|---|---|
| _(none yet)_ | | |
