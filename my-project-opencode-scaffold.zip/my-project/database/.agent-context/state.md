# Database — Current State

> This file is a SNAPSHOT. Overwrite it completely at the end of every
> session. Do not append.

**Last updated:** [YYYY-MM-DD] by [agent/session identifier]

## Status: `not started`

## In progress

- (nothing yet — initial scaffold)

## Blocked

- (none)

## Done recently

- (none yet)

## Next step

- Fill in `database/AGENTS.md` placeholders (Oracle version, schema owner,
  migration tool) and create the first migration (baseline schema) before
  real feature work starts.

## Environment notes

- Migration tool status command: `[e.g. flyway info]`
- Local/dev connection: via env var `[e.g. DB_URL, DB_USER, DB_PASSWORD —
  names only, never values]`
