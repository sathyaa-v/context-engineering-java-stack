# database/ — Oracle Rules

> Loaded only when `oracle-db-agent` (or a session working directly in
> this folder) is active.

## Stack

- Oracle version: [19c / 21c / 23ai — specify]
- Schema owner: [SCHEMA_NAME]
- Migration tool: [Flyway / Liquibase — specify]
- Connectivity: [TNS alias / EZConnect string pattern — no credentials
  here, ever]

## Folder structure

```
database/sql/
├── migrations/         versioned migration scripts, one logical change
│                        each: V<n>__<description>.sql (Flyway) or
│                        changelog format (Liquibase)
├── seed/                reference/lookup data scripts, idempotent
└── plsql/                packages, procedures, functions, triggers —
                           each file has a header comment (purpose,
                           last-modified date, author/agent)
```

## Non-negotiable rules

1. **No destructive operation (DROP, TRUNCATE, unbounded DELETE/UPDATE)
   runs without explicit user confirmation in-session**, regardless of
   configured tool permissions. State impact first, then wait.
2. **All schema changes are versioned migrations** — never a manual
   ad-hoc `ALTER TABLE` applied outside the migration tool, even for
   "quick fixes."
3. **No credentials or connection strings** in any file in this repo,
   including `.agent-context/` notes — reference env var names only.
4. Every table/column the backend maps to an entity is documented in
   `shared-context/data-contracts.md` in the same session it changes.
5. Bind variables in all example/generated SQL — no string concatenation,
   even in throwaway scripts, to avoid modeling bad habits.
6. New foreign key columns get an index unless there's a documented
   reason not to (`decisions.md`).
7. Naming: `[UPPER_SNAKE_CASE]` tables/columns; constraints prefixed
   `PK_`, `FK_`, `UQ_`, `CK_`; indexes prefixed `IDX_`.

## Context files in this folder

- `.agent-context/state.md` — read first, overwrite last, every session
- `.agent-context/memory.md` — durable conventions/gotchas
- `.agent-context/plan.md` — active checklist for the current feature
- `.agent-context/schema-notes.md` — living reference of tables/indexes/
  PL-SQL objects and their purpose
- `.agent-context/decisions.md` — ADR-style log, append-only
- `.agent-context/session-log.md` — dated one-liners, append-only,
  reference-only (not auto-loaded)
