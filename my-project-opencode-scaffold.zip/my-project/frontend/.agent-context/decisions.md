# Frontend — Decisions Log

> ADR-style, append-only. Reference-only, not auto-loaded.

Format:
```
## [YYYY-MM-DD] Short title
**Decision:** what was decided
**Why:** the reasoning
**Alternatives considered:** what else was on the table, and why rejected
```

---

## [YYYY-MM-DD] Example — Signals over NgRx for feature state
**Decision:** Use signal-based services for feature-local state; reserve
NgRx (if introduced) strictly for cross-cutting state like auth/session.
**Why:** Angular 19's signals cover most component/feature state needs
with far less boilerplate; NgRx adds real value only for genuinely
global, complex state.
**Alternatives considered:** NgRx everywhere (rejected — overkill for
most features, slows down delivery); plain RxJS BehaviorSubjects
(rejected — signals are now the more idiomatic Angular 19 pattern).

<!-- Add new entries above this line. -->
