# Frontend — Memory

> Durable facts, conventions, and gotchas. Not a log — keep it curated.

## Conventions

- Component selector prefix: `[e.g. app-]`
- File naming: `kebab-case`, Angular CLI defaults
  (`user-profile.component.ts` or the new schematics style without the
  `.component` suffix if the project has adopted it — specify which).
- State pattern: signals in a feature-level service for shared state;
  local `signal()` for component-only state; `[NgRx only for: e.g. large
  cross-cutting state like auth/cart — specify boundary]`.
- Forms: `[Reactive Forms — always, not template-driven]`.
- HTTP error handling: `[centralized HttpInterceptor that normalizes
  errors to a common shape matching shared-context/api-contracts.md]`.

## Known gotchas

- [Example: "@for requires a track expression — always track by a stable
  id field, never by index, for lists that can reorder."]
- [Example: "Signals inside effect() that read another signal will
  re-run on every change of that signal — be careful about triggering
  HTTP calls inside effect() without an explicit guard."]

## Testing

- Unit tests: `[Jasmine/Karma or Jest — specify]`
- Run: `[ng test]`
- E2E: `[Playwright/Cypress]`, run: `[command]`

## Dependencies worth knowing about

- [List any non-obvious library choices and why]
