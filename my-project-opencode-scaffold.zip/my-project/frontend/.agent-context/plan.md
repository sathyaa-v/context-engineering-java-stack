# Frontend — Active Plan

> Checkbox tasks for the CURRENT feature only. When complete, archive to
> `session-log.md` and clear this file.

## Feature: [none active — scaffold state]

- [ ] Confirm Angular 19 project setup (standalone bootstrap, routing,
      environments)
- [ ] Set up `core/` (HTTP interceptor for auth + error normalization)
- [ ] Set up `shared/` (base UI components/pipes as needed)
- [ ] Wire API base URL via `environment.ts`
- [ ] Build first real feature: [TBD]
