# Frontend — Session Log

> Append-only, dated. Never auto-loaded — reference-only.

Format: `- [YYYY-MM-DD HH:MM] <one-line summary of what changed>`

---

- [YYYY-MM-DD HH:MM] Scaffold created. No feature work yet.
