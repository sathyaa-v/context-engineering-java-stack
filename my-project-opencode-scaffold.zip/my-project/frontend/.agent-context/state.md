# Frontend — Current State

> This file is a SNAPSHOT. Overwrite it completely at the end of every
> session. Do not append.

**Last updated:** [YYYY-MM-DD] by [agent/session identifier]

## Status: `not started`

## In progress

- (nothing yet — initial scaffold)

## Blocked

- (none)

## Done recently

- (none yet)

## Next step

- Fill in `frontend/AGENTS.md` placeholders (styling approach, state
  management scope, testing framework) before starting real feature work.

## Environment notes

- Local run command: `[e.g. ng serve]`
- Local port: `[e.g. 4200]`
- API base URL (dev): `[e.g. proxied to localhost:8080 via proxy.conf.json]`
