# frontend/ — Angular 19 Rules

> Loaded only when `angular-agent` (or a session working directly in this
> folder) is active.

## Stack

- Angular: 19.x
- Language: TypeScript [strict mode: true]
- Package manager: [npm / pnpm — specify]
- Styling: [SCSS / Tailwind / Angular Material — specify]
- State: signals + services by default; [NgRx if/where used — specify
  scope]
- Testing: [Jasmine/Karma default, or Jest if migrated — specify]
- E2E: [Playwright / Cypress — specify]

## Angular 19 conventions — use these, not the pre-v17 patterns

- **Standalone components** for everything new — no `NgModule` unless the
  codebase has a documented legacy reason (check `memory.md`).
- **New control-flow syntax** in templates: `@if`, `@for` (with `track`),
  `@switch` — not `*ngIf` / `*ngFor` / `*ngSwitch`.
- **Signals** (`signal()`, `computed()`, `effect()`, `linkedSignal()`) for
  component-local reactive state.
- **`input()` / `output()`** function APIs instead of `@Input()` /
  `@Output()` decorators for new components.
- **`inject()`** function for DI in most cases, instead of constructor
  injection, where it improves readability (constructor injection is
  still fine and not banned).
- Lazy-loaded routes via `loadComponent()` / `loadChildren()` in a
  standalone route config, not `RouterModule.forChild()`.

## Folder structure

```
src/app/
├── core/              singleton services, interceptors, guards
├── shared/            reusable dumb components, pipes, directives
├── features/
│   └── <feature>/
│       ├── data-access/    services + API calls for this feature
│       ├── ui/               presentational components
│       └── feature-*.routes.ts
└── app.routes.ts
```

## Non-negotiable rules

1. No component calls `HttpClient` directly — always through a typed
   service in `core/services/` or a feature's `data-access/`.
2. Request/response types in frontend services must match
   `shared-context/api-contracts.md` exactly — treat that file as the
   contract, not the backend source code.
3. Every component with real logic gets a `.spec.ts`.
4. Accessibility: interactive elements get proper ARIA roles/labels;
   don't ship a feature that fails basic keyboard navigation.
5. No hardcoded API base URLs in components/services — use
   `environment.ts` / `environment.prod.ts`.

## Context files in this folder

- `.agent-context/state.md` — read first, overwrite last, every session
- `.agent-context/memory.md` — durable conventions/gotchas
- `.agent-context/plan.md` — active checklist for the current feature
- `.agent-context/decisions.md` — ADR-style log, append-only
- `.agent-context/session-log.md` — dated one-liners, append-only,
  reference-only (not auto-loaded)
