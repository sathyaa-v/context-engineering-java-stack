# API Contracts — Spring Boot ↔ Angular

> Source of truth for REST endpoint shapes. The frontend builds against
> THIS file, not the backend source code. Backend agent updates this file
> in the same session it changes an endpoint. If code and this file
> disagree, that's a bug to fix, not a signal to trust the code silently.

## Conventions

- Base path: `[e.g. /api/v1]`
- Auth: `[e.g. Bearer JWT in Authorization header]`
- Content type: `application/json` for all request/response bodies
- Pagination (list endpoints): `[e.g. ?page=0&size=20&sort=field,asc ->
  { content: [...], page, size, totalElements, totalPages }]`

## Standard error envelope

All non-2xx responses return this shape:

```json
{
  "timestamp": "2026-07-16T10:00:00Z",
  "status": 400,
  "error": "VALIDATION_ERROR",
  "message": "Human-readable summary",
  "details": [
    { "field": "email", "message": "must be a valid email address" }
  ],
  "path": "/api/v1/users"
}
```

## Endpoints

> Add one section per endpoint. Keep entries current — this is the
> contract, not documentation of history.

### Example — `GET /api/v1/health`

**Purpose:** liveness check

**Response `200`:**
```json
{ "status": "UP" }
```

---

### `[METHOD] [/api/v1/...]`

**Purpose:** [one line]

**Auth required:** [yes/no, role if applicable]

**Request:**
```json
{}
```

**Response `[status code]`:**
```json
{}
```

**Errors:**
| Status | Condition |
|---|---|
| 400 | [when] |
| 404 | [when] |

<!-- Duplicate the block above for each real endpoint as it's built. -->
