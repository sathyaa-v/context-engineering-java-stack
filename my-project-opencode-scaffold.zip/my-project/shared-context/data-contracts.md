# Data Contracts — Spring Boot ↔ Oracle

> Source of truth for entity-to-table mapping. Database agent and backend
> agent both update this file in the same session a table or entity
> changes. If the JPA entity and the Oracle table disagree, that's a bug.

## Conventions

- Entity field names: `camelCase`
- Column names: `UPPER_SNAKE_CASE`
- Mapping strategy: `[explicit @Column(name=...) on every field / naming
  strategy — specify which, e.g.
  PhysicalNamingStrategyStandardImpl + SNAKE_CASE]`

## Entity ↔ Table mappings

> Add one section per entity. Keep entries current.

### Example — `User` ↔ `USERS`

| Entity field | Type | Column | DB type | Nullable | Notes |
|---|---|---|---|---|---|
| id | Long | ID | NUMBER (IDENTITY) | no | PK |
| email | String | EMAIL | VARCHAR2(255) | no | unique |
| createdAt | Instant | CREATED_AT | TIMESTAMP WITH TIME ZONE | no | |
| updatedAt | Instant | UPDATED_AT | TIMESTAMP WITH TIME ZONE | no | |

**Relationships:** [e.g. `@OneToMany` to `Order`, mapped by `user`]

---

### `[Entity]` ↔ `[TABLE_NAME]`

| Entity field | Type | Column | DB type | Nullable | Notes |
|---|---|---|---|---|---|
| | | | | | |

**Relationships:** [describe]

<!-- Duplicate the block above for each real entity as it's built. -->
