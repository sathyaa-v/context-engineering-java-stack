# Feature Status — Cross-Stack View

> Maintained by the orchestrator agent. One row per feature that spans
> more than one stack. This is the fastest way to answer "what's actually
> done end-to-end" without reading three separate state.md files.

| Feature | Database | Backend | Frontend | Status | Last updated |
|---|---|---|---|---|---|
| _(example)_ Update user email | done | done | in progress | partial | [YYYY-MM-DD] |

## Notes

- "done" means merged and tested in that stack, not just written.
- "Status" is `not started` / `partial` / `done end-to-end`.
- When a feature reaches `done end-to-end`, it's fine to remove the row
  after a release or archive it below.

## Archived (shipped) features

| Feature | Shipped date |
|---|---|
| _(none yet)_ | |
