# System Architecture — [PROJECT_NAME]

> This file is loaded globally, into EVERY agent session, every time.
> Keep it short — a few paragraphs and one diagram, not a full design
> doc. Anything stack-specific belongs in that stack's own AGENTS.md.

## One-paragraph overview

[What this system does, who uses it, and the core domain in 2-3
sentences.]

## High-level component diagram

```
[Browser]
    |
    | HTTPS
    v
[Angular 19 SPA]  --(REST/JSON, see api-contracts.md)-->  [Spring Boot API]
                                                                  |
                                                                  | JDBC (ojdbc)
                                                                  v
                                                          [Oracle Database]
```

## Deployment topology

- Frontend hosted: `[e.g. static build served via Nginx / CDN]`
- Backend hosted: `[e.g. containerized, deployed to K8s/ECS/VM]`
- Database: `[e.g. Oracle on-prem / OCI Autonomous Database / RDS for
  Oracle]`
- Environments: `[dev / staging / prod — and how they differ]`

## Cross-cutting concerns

- **Auth:** [approach — e.g. Angular stores JWT in memory, sent as
  Bearer token, validated by Spring Security resource server config]
- **Logging/observability:** [tool/approach]
- **CI/CD:** [pipeline tool, what triggers a deploy]

## Where to look for detail

- API shapes → `shared-context/api-contracts.md`
- Entity/table mapping → `shared-context/data-contracts.md`
- What's built so far → `shared-context/feature-status.md`
- Stack-specific conventions → `backend/AGENTS.md`,
  `frontend/AGENTS.md`, `database/AGENTS.md`
